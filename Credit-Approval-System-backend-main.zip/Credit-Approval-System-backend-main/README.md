﻿# Credit-Approval-System-backend
In this assignment you will be working on creating a credit approval
system based on past data as well as future transactions, the goal of this
assignment is to assess the proficiency with the JavaScript/NodeJS stack,
using background tasks as well handing operations on Databases.
